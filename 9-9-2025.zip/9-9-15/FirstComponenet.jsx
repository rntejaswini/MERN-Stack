import React from 'react'

function FirstComponent(ambika) {
  return (
    <div><h1>FirstComponent {ambika.name}</h1>
        <SecondComponent phno="9663793588"/>
    </div>
  )
}
function SecondComponent(ambika1) {
  return (
    <div>
        SecondComponent {ambika1.phno }
    </div>
  )
}

export default FirstComponent
