import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Example from './hooks'
import Counter from './counter'
import Timer from './cleanup'
import UsersList from './Userslist'
import Greeting from './Css'
import External from './Externalcss'
import Button from './Cssmodules'
import ProductCard from './StyledComponents'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <Example/> */}
      {/* <Counter/>
      <Timer/> */}
      {/* <UsersList/> */}
      {/* <Greeting/> */}
      <External/>
      <Button/>
      <ProductCard/>
   
      

    </>
  )
}

export default App
