import React from 'react'
import { Link } from 'react-router-dom'

function Index1() {
  return (
    <div>
        <h1>This is a Index Page</h1>
        <nav>
            <Link to='/home'>HomePage ||</Link>
             <Link to='/about'>AboutUS ||</Link>
              <Link to='/contact'>contactUS</Link>

        </nav>
    </div>

  )
}

export default Index1