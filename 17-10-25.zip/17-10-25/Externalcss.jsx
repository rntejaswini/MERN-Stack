import "./Externalcss.css"
function External(){
    return <h6 className="title">React External CSS</h6>;
}
export default External;