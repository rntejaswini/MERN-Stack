import styled from "styled-components";
import React from "react";
function Productcard(){
    const Card=styled.div`
    background-color:rgba(45, 240, 6);
    border-radius:40px;
    padding:30px;
    text-align:center;
    box-shadow: 0 6px 20px rgba(247, 31, 96);
    `;

const Title=styled.h3`
color:#333;
`;
return(
    <Card>
    <Title>Product Name</Title>
    <p>$25.99</p>
    </Card>
);
}
export default Productcard