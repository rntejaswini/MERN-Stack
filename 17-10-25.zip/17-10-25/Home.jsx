import React from 'react'
import { useNavigate } from 'react-router-dom'
function Home() {
    const navigate=useNavigate();
    function handleLogin(){
    console.log("Home Page Button clicked")
    navigate('/contact');
}
  return (
    <div>
      <h1>This is a Home page</h1>
       <button id=''>ClickMe</button>
    </div>
 
  )
}

export default Home
