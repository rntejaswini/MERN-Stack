import React, {useReducer} from "react";
function Count(){
    function reducer(state, action){
        switch(action.type){
            case "Plus1":
                return { count:state.count+1};
            case "Minus1":
                return {count: state.count-1};
            case "INCREMENTBY2":
                return {count: state.count+2};
            case "RESET":
                return { count:0};
            default:
                return state;
        }
    }
    const[state, dispatch]=useReducer(reducer,{count:0});
    return(
        <div style={{textAlign:"center", marginTop:"50px"}}>
            <h2>Count:{state.count}</h2>
            <button onClick={()=>dispatch({type:"Plus1"})}>+Increment</button>
            <button onClick={()=>dispatch({type:"Minus1"})}>-Decrement</button>
            <button onClick={()=>dispatch({type:"INCREMENTBY2"})}>+2Increment</button>
             <button onClick={()=>dispatch({type:"RESET"})}>Reset</button>
        </div>
    )
}
export default Count;