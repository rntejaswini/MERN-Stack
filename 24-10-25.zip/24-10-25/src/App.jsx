import { Component, useState } from 'react'
import React from 'react'
import Counter from './Counter'
import Count from './CounterReducer'
import WithUseMemo from './Memo'
import Child from './Callback'
import Parent from './Callback'
import CounterApp from './CounterApp'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>

      {/* <WithUseMemo/>
      <Parent/> */}

      <CounterApp/>
 
      
    </>
  )
}

export default App
