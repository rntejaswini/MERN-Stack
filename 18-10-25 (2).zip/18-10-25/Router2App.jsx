import {React, lazy, Suspense} from "react";
import {BrowserRouter,Routes, Route} from "react-router-dom";

const Home=lazy(()=>import("./Home"));
const About=lazy(()=>import("./About"));
const Contact=lazy(()=>import("./Contact"));

function  App(){
    return(
        <Suspense fallback={<h3>loading...</h3>}>
          <BrowserRouter>
          <Routes>
                <Route path="/Home" element={<Home/>}/>
                <Route path="/about" element={<About/>}/>
                <Route path="/contact" element={<Contact/>}/>
            </Routes></BrowserRouter>

            
         
        </Suspense>
    );

}
export default App;
