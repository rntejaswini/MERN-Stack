import React from 'react'

function Parent1({studentName}){
    return(
        <div style={{background:"#4e9cbdff", margin:"10px", padding:"10px"}}>
            <h2>Parent Component</h2>
            <Child studentName={studentName}/>
        </div>
    );
}
function Child({studentName}){
    return(
        <div style={{background:"#99d2deff", margin:"10px", padding:"10px"}}>
            <h3>Child Component</h3>
            <GrandChild studentName={studentName}/>
        </div>
    );
}
function GrandChild({studentName}){
    return(
        <div style={{background:"#30b0d1ff", margin:"10px", padding:"10px"}}>
            <h4>GrandChild Component</h4>
            <GreatGrandChild studentName={studentName}/>
        </div>
    );
}
function GreatGrandChild({studentName}){
    return(
        <div style={{background:"#12e3fbff", margin:"10px", padding:"10px"}}>
            <h5>GreatGrandChild Component</h5>
           <p>Hello <b>{studentName}</b>, this value was passed from the App Components!</p>
        </div>
    );
}
export default Parent1;
