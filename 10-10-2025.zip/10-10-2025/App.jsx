import ClassResult from './ConditionalRendering'
import Car from './LogicalAnd'
import Car1 from './Destructuring1'
import Car2 from './Destructuring2'
import Parent1 from './Propdrilling'

function App() {
  return (
    <div>
   
   <Car brand='Fortuner'/>
   <Car1 color='Black'/>
   <Car2 brand='BMW'/>
   <Parent1 studentName='Tejaswini'/>
     </div>
  )
}

export default App