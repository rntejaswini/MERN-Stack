import React from 'react'

function Car2(props){
    const {brand, model}=props;
    return(
        <h2>I love my ! {brand}</h2>
    )
}
export default Car2
