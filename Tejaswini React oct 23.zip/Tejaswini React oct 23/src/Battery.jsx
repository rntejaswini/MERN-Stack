
export default function Battery({ level, charging, chargingTime, dischargingTime }) {
  return (
    <div>
      <h3>{charging ? " Charging" : " Discharging"}</h3>
      <div
        style={{
          width: "200px",
          height: "20px",
          border: "1px solid #333",
          background: "#eee",
          marginBottom: "8px",
        }}
      >
        <div
          style={{
            width: `${level}%`,
            height: "100%",
            backgroundColor: charging ? "limegreen" : "orange",
          }}
        ></div>
      </div>
      <p>{level.toFixed(0)}%</p>
    </div>
  );
}