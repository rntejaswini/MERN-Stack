import React from 'react'
function HtmlForms(){
    return(
        <div>
            <form>
                <input type="email" id="user"/>
                <input type="password" id="user"/>
                <button onclick=''>Submit</button>
            </form>
        </div>
    )
}
export default HtmlForms;