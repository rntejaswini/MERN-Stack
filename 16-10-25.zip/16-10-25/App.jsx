import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Example from './hooks'
import Counter from './counter'
import Timer from './cleanup'
import UsersList from './Userslist'
import Greeting from './Css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <Example/> */}
      {/* <Counter/>
      <Timer/> */}
      {/* <UsersList/> */}
      <Greeting/>
      

    </>
  )
}

export default App
